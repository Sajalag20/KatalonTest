using KatalonShopDemoTest.PageObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;
using System.Linq;
using KatalonShopDemoTest.Framework;

namespace KatalonShopDemoTest.StepDefinitions
{
    [Binding]
    public class RandomCartShopingTestsStepDefinitions : BaseTest
    {
        private string webSiteLink = "https://cms.demo.katalon.com/";

        public RandomCartShopingTestsStepDefinitions()
        {
           
        }

        [Given(@"I add four random item to my cart")]
        public void GivenIAddFourRandomItemToMyCart()
        {
            GetDriver().Navigate().GoToUrl(webSiteLink);
            var homePage = new HomePage(GetDriver());
            homePage.AddItemsToCart(4);
        }

        [When(@"I view my cart")]
        public void WhenIViewMyCart()
        {
            var cart = new CartPage(GetDriver());
            cart.ViewCart();
        }

        [Then(@"I find total four items listed in my cart")]
        public void ThenIFindTotalFourItemsListedInMyCart()
        {
            Assert.AreEqual(4, (new CartPage(GetDriver())).GetCartItemCount());
        }

        [When(@"I searched for the lowest item")]
        public void WhenISearchedForTheLowestItem()
        {
            var cartPage = new CartPage(GetDriver());
            cartPage.WhenISearchForTheLowestPriceItem();
        }

        [When(@"I am able to remove the lowest price item from the cart")]
        public void WhenIAmAbleToRemoveTheLowestPriceItemFromTheCart()
        {
            var cartPage = new CartPage(GetDriver());
            cartPage.WhenIAmAbleToRemoveTheLowestPriceItemFromMyCart();
        }

        [Then(@"I am able to verify three item in my cart")]
        public void ThenIAmAbleToVerifyThreeItemInMyCart()
        {
            Assert.AreEqual(3, (new CartPage(GetDriver())).GetCartItemCount());
        }
    }
}
