﻿using KatalonShopDemoTest.PageObjects.BasePages;
using NUnit.Framework.Internal;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace KatalonShopDemoTest.PageObjects
{
    public class SelectOptionsPage : BasePage
    {
      
        public SelectOptionsPage(WebDriver driver) : base(driver)
        {
        }

        public void SelectOption()
        {
            ImplicitWait();
            WebElement dropdownElement = (WebElement)driver.FindElement(By.Id("pa_color"));
            SelectElement select = new SelectElement(dropdownElement);
            select.SelectByIndex(1);
            ImplicitWait();
            var button = driver.FindElement(By.CssSelector(".button"));
            button.Click();
            ImplicitWait();
            var homeButton = driver.FindElement(By.LinkText("HOME"));
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", homeButton);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", homeButton);


        }


    }
}
