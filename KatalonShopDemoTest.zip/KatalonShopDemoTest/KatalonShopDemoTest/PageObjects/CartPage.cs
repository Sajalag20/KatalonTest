﻿using KatalonShopDemoTest.PageObjects.BasePages;
using OpenQA.Selenium;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KatalonShopDemoTest.PageObjects
{
    public class CartPage : BasePage
    {
        public CartPage(WebDriver driver) : base(driver)
        {
        }

        public void ViewCart()
        {
            var menuElement = driver.FindElement(By.CssSelector(".menu"));
            var cartElement = menuElement.FindElement(By.LinkText("CART"));
            cartElement.Click();
        }


        public IWebElement WhenISearchForTheLowestPriceItem()
        {
            var cartItems = driver.FindElements(By.CssSelector(".cart_item"));
            var lowestCartItem = cartItems.First();
            var lowestDriver = lowestCartItem.FindElement(By.CssSelector(".woocommerce-Price-amount"));
            var lowestPrice = Convert.ToDecimal(lowestDriver.Text.TrimStart('$')); ;

            foreach (var item in cartItems)
            {
                var cartIs = item.FindElement(By.CssSelector(".woocommerce-Price-amount"));
                if (lowestPrice > Convert.ToDecimal(cartIs.Text.TrimStart('$')))
                {
                    lowestPrice = Convert.ToDecimal(cartIs.Text.TrimStart('$'));
                    lowestCartItem = item;
                }
            }

            return lowestCartItem;

        }

        public void WhenIAmAbleToRemoveTheLowestPriceItemFromMyCart()
        {
            var lowestCartItem = WhenISearchForTheLowestPriceItem();
          
            ImplicitWait();
            var removeButton = lowestCartItem.FindElement(By.CssSelector(".remove"));
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", removeButton);
        }

         
        public int GetCartItemCount()
        {
            ImplicitWait();
            Thread.Sleep(5000);
            var cartItems = driver.FindElements(By.CssSelector(".cart_item"));
            return Convert.ToInt32(cartItems.Count);
        }
    }
}
