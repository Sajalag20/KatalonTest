﻿using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KatalonShopDemoTest.PageObjects.BasePages
{
    public class BasePage
    {
        private static int TimeOut = 60;
        protected WebDriver driver;
        protected WebDriverWait wait;


        public BasePage(WebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(20));
        }

        protected void ImplicitWait()
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
        }


       
    }
}
