﻿using KatalonShopDemoTest.PageObjects.BasePages;
using OpenQA.Selenium;
using OpenQA.Selenium.DevTools.V111.Input;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SeleniumExtras.WaitHelpers;

namespace KatalonShopDemoTest.PageObjects
{
    public class HomePage : BasePage
    {
     
        HashSet<int> randomSet = new HashSet<int>();

        public HomePage(WebDriver driver) : base(driver)
        {

        }

        public void AddItemsToCart(int noOfItems)
        {

            while (noOfItems > 0)
            {
                ImplicitWait();
                IWebElement element = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".product")));
                
                var demo = GetListOfProducts();
                var randomItem = pickRandomNumber(1, demo.Count);
                if (!randomSet.Contains(randomItem))
                {
                    randomSet.Add(randomItem);
                    ImplicitWait();
                  
                    if (CheckItem(demo[randomItem]))
                    {
                        noOfItems--;
                    }
                }
            }
        }

        private List<IWebElement> RemovePickedItemFromList(List<IWebElement> webElements, int n)
        {
            webElements.RemoveAt(n);
            return webElements;
        }

        private List<IWebElement> GetListOfProducts()
        {
            return driver.FindElements(By.CssSelector(".product")).ToList();
        }

        private int pickRandomNumber(int startNumber, int endNumber)
        {
            var random = new Random();
            return random.Next(startNumber, endNumber);
        }

        public bool CheckItem(IWebElement webElement)
        {
            ImplicitWait();
            
            var button = webElement.FindElement(By.CssSelector(".button"));
            var getInnerText = button.GetAttribute("class");
            if (getInnerText.Contains("ajax_add_to_cart"))
            {
                ImplicitWait();
                wait.Until(ExpectedConditions.ElementExists(By.CssSelector(".button")));
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", button);
                return true;
            }
            else if (getInnerText.Contains("product_type_variable"))
            {
                ImplicitWait();
                button.Click();
                var selectOptionsPage = new SelectOptionsPage(driver);
                selectOptionsPage.SelectOption();
                return true;
            }

            return false;
        }

    }
}
