﻿using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KatalonShopDemoTest.Framework
{
    public class BaseTest
    {
        private WebDriver driver;

        [BeforeScenario]
        public void BeforeScenario()
        {
            driver = new ChromeDriver();
            
        }

        [AfterScenario]
        public void AfterScenario()
        {
            if (null != driver)
            {
                driver.Close();
                driver.Quit();
            }
        }

        public WebDriver GetDriver()
        {
            return driver;
        }
    }
}
